# my package
This package is designed to learn how to install and import customized python packages 